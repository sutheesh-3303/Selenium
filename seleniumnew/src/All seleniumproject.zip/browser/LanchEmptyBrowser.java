package browser;

import org.openqa.selenium.edge.EdgeDriver;

public class LanchEmptyBrowser {

	public static void main(String[] args) 
	{
		EdgeDriver drive=new EdgeDriver();
		
	}

}
